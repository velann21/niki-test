package apk.bookmyShow.interfaces;

import java.util.ArrayList;

import apk.bookmyShow.helper.GetData;

//import WhatsApp1.helper.GetData;

public interface GetDataInterface {
	
	
	
	public ArrayList fromExcel(String filePath,String sheetName,int rowIndex, int cellIndex) throws Exception;
	
	public String fromProperties(String fileName , String Keys,String className) throws GetData;
	
	public String fromExcelOneData();
	
	
}
