package apk.bookmyShow.helper;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.openqa.selenium.By;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class Handler extends RuntimeException {

	String ExceptionValue = null;

	static String SDirPath = System.getProperty("user.dir");
	static String sConfigFile = SDirPath + "\\resources\\external_data\\config.properties";

	public Handler() {

	}

	Handler(String ExceptionValue) {
		this.ExceptionValue = ExceptionValue;
	}

	public String toString() {
		return ExceptionValue;
	}

	static Class classtype;

	public static String ClassDetails(String ClassName) {
		try {
			classtype = Class.forName(ClassName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return classtype.getSimpleName();
	}
	public int getMaxArray(int[] inputArray) {
		int maxValue = inputArray[0];
		for (int i = 1; i < inputArray.length; i++) {
			if (inputArray[i] > maxValue) {
				maxValue = inputArray[i];
			}
		}
		return maxValue;
	}

	// Method for getting the minimum value
	public int getMinArray(int[] inputArray) {
		int minValue = inputArray[0];
		for (int i = 1; i < inputArray.length; i++) {
			if (inputArray[i] < minValue) {
				minValue = inputArray[i];
			}
		}
		return minValue;
	}

	public <T> void closeCurrentApp(T driver) {
		if (driver == null || !(driver instanceof AndroidDriver)) {
			throw new Handler("driverNullExceptionIn" + Handler.ClassDetails("com.WhatsApp1.helper.Handler"));
			// throw new Handler("In method closeCurrentApp");

		}
		((AppiumDriver) driver).closeApp();
	}

	public <T> void OpenApp(T driver) {
		if (driver == null || !(driver instanceof AndroidDriver)) {
			throw new Handler("driverNullExceptionIn" + Handler.ClassDetails("com.WhatsApp1.helper.Handler"));
			// throw new Handler("In method closeCurrentApp");
		}
		((AppiumDriver) driver).launchApp();
	}

	public <T> WebDriver switcher(T driver, String contextName) {
		WebDriver driver1 = ((AppiumDriver) driver).context(contextName);
		return driver1;
	}

	public <T> String Native_Web_view_Checker(T driver) {
		return ((AppiumDriver) driver).getContext();
	}

	public void click_Button(WebElement element) {
		element.click();
		System.out.println("Button clicked");
	}

	public void click_ButtonArrays(WebElement[] element, int startindex) {
		for (int i = startindex; i <= element.length; i++) {
			element[i].click();
		}
	}

	public void text_Writer(WebElement element, String Value) {
		element.sendKeys(Value);
	}

	public void text_WriterArrays(WebElement[] element, String[] Value) {
		try {
			System.out.println("Am in Text Arrays");
			for (int i = 0; i <= element.length; i++) {
				element[i].sendKeys(Value[i]);
			}
		} catch (Exception e) {

		}
	}

	public <T> ScreenOrientation ScreenModeCheck(T driver) {
		return ((AppiumDriver) driver).getOrientation();
	}

	public <T> Set getNative_WebView(T driver) {
		return ((AppiumDriver) driver).getContextHandles();
	}

	public <T> void page_Scroller(T driver, int startXaxis, int startY, int endX, int endY, int timeMs) {
		((AppiumDriver) driver).swipe(startXaxis, startY, endX, endY, timeMs);
	}

	public <T> boolean webElementPresentCheck(T driver, By byType) {
		if (((AppiumDriver) driver).findElement(byType).isDisplayed() == true) {
			return true;
		} else {
			return false;
		}

	}

	public String popupHandler(AppiumDriver driver) {
		if (alertChecker(driver) == true) {
			driver.switchTo().alert().accept();
			return "Alert handled";
		} else {
			// System.out.println("Alert Not Present");
			return "Alert is not visible";
		}

	}

	public boolean alertChecker(AppiumDriver driver) {
		try {
			driver.switchTo().alert();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public DesiredCapabilities DesiredCapabilitiesNative_AppwithReset(String apppath, GetData getter) throws GetData {
		File file = new File(apppath);

		DesiredCapabilities cap = new DesiredCapabilities();

		cap.setCapability(DesiredCapabiltiesKeys.appiumKey,
				getter.fromProperties(sConfigFile, "AUTOMATIONNAME", "com.Whatsapp.RegressionTests.WhatsApp_Sc_001"));

		cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Device");

		cap.setCapability(DesiredCapabiltiesKeys.deviceNamekey,
				getter.fromProperties(sConfigFile, "DEVICENAME", "com.Whatsapp.RegressionTests.WhatsApp_Sc_001"));

		cap.setCapability(DesiredCapabiltiesKeys.appPathKey, file.getAbsolutePath());

		cap.setCapability(DesiredCapabiltiesKeys.appActivityKey,
				getter.fromProperties(sConfigFile, "APP_ACTIVITY", "com.Whatsapp.RegressionTests.WhatsApp_Sc_001"));

		cap.setCapability(DesiredCapabiltiesKeys.appPkgKey,
				getter.fromProperties(sConfigFile, "APP_PACKAGE", "com.Whatsapp.RegressionTests.WhatsApp_Sc_001"));

		cap.setCapability(DesiredCapabiltiesKeys.applaunchExistingstatusKey, true);

		cap.setCapability(DesiredCapabiltiesKeys.appdestroylastKey, true);

		return cap;
	}

	public DesiredCapabilities DesiredCapabilitiesNative_App_Withoutreset(String apppath, GetData getter)
			throws GetData {
		File file = new File(apppath);

		DesiredCapabilities cap = new DesiredCapabilities();

		cap.setCapability(DesiredCapabiltiesKeys.appiumKey,
				getter.fromProperties(sConfigFile, "AUTOMATIONNAME", "com.Whatsapp.RegressionTests.WhatsApp_Sc_001"));

		cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Device");

		cap.setCapability(DesiredCapabiltiesKeys.deviceNamekey,
				getter.fromProperties(sConfigFile, "DEVICENAME", "com.Whatsapp.RegressionTests.WhatsApp_Sc_001"));

		cap.setCapability(DesiredCapabiltiesKeys.appPathKey, file.getAbsolutePath());

		cap.setCapability(DesiredCapabiltiesKeys.appActivityKey,
				getter.fromProperties(sConfigFile, "APP_ACTIVITY", "com.Whatsapp.RegressionTests.WhatsApp_Sc_001"));

		cap.setCapability(DesiredCapabiltiesKeys.appPkgKey,
				getter.fromProperties(sConfigFile, "APP_PACKAGE", "com.Whatsapp.RegressionTests.WhatsApp_Sc_001"));

		cap.setCapability(DesiredCapabiltiesKeys.applaunchExistingstatusKey, false);

		cap.setCapability(DesiredCapabiltiesKeys.appdestroylastKey, false);

		return cap;
	}

	public DesiredCapabilities DesiredCapabilties_MobileBrowser(String BrowserName, GetData getter) throws GetData {

		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(DesiredCapabiltiesKeys.appiumKey,
				getter.fromProperties(sConfigFile, "AUTOMATIONNAME", "com.Whatsapp.RegressionTests.WhatsApp_Sc_001"));
		cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Device");
		cap.setCapability(DesiredCapabiltiesKeys.deviceNamekey,
				getter.fromProperties(sConfigFile, "DEVICENAME", "com.Whatsapp.RegressionTests.WhatsApp_Sc_001"));
		cap.setCapability(DesiredCapabiltiesKeys.browserKey, BrowserName);
	
		return cap;

	}

	public void xmlReader_Writer(String XMlFilepath, String tagName, String attributeProp, String attributeValue)

	{
		File file = new File(XMlFilepath);
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		DocumentBuilder db = null;
		try {
			db = dbf.newDocumentBuilder();
		} catch (ParserConfigurationException e1) {
			e1.printStackTrace();
		}

		Document dom = null;
		try {
			dom = db.parse(file);
		} catch (SAXException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		dom.getDocumentElement().normalize();

		System.out.println(dom.getDocumentElement().getNodeName());

		NodeList nlist = dom.getElementsByTagName(tagName);

		System.out.println("---------------------------------------");

		for (int temp = 0; temp < nlist.getLength(); temp++) {
			Node node = nlist.item(temp);

			System.out.println("Current Node" + node.getNodeName());

			if (node.getNodeType() == node.ELEMENT_NODE) {
				Element element = (Element) node;

				element.setAttribute(attributeProp, attributeValue);
				System.out.println(element.getAttribute(attributeProp));
			}
		}

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = null;
		try {
			transformer = transformerFactory.newTransformer();
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DOMSource source = new DOMSource(dom);
		StreamResult result = new StreamResult(file);
		try {
			transformer.transform(source, result);
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void screenCapture() {
		System.out.println("Am in Screens");
	}
    
	public void elementToPresentWaiter(WebDriver driver,By locator){
		WebDriverWait wd=new WebDriverWait(driver,20);
		ExpectedConditions.presenceOfElementLocated(locator);
	}
	
	public static void main(String[] args) throws GetData, MalformedURLException, InterruptedException {

		Handler handle = new Handler();
		GetData getters = GetData.newInstance();
		DesiredCapabilities cap = handle.DesiredCapabilties_MobileBrowser(
				getters.fromProperties(sConfigFile, "BROWSER_NAME", "WhatsApp1.Config.TestConfig"), getters);

		AndroidDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4721/wd/hub"), cap);
		driver.get("http://www.google.com");
	}
	// while(driver.findElement(By.xpath("//android.widget.CheckedTextView[contains(@text='Allahabad')]")))

}
