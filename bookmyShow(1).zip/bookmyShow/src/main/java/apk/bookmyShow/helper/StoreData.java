package apk.bookmyShow.helper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class StoreData {

	public static void CreateExcel_97_03(String filePath, String sheetName) {
		HSSFWorkbook workbook = new HSSFWorkbook();

		HSSFSheet sheet = workbook.createSheet("Sheet1");

		HSSFRow row = sheet.createRow(1);

		HSSFCell column = row.createCell(1);

		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePath));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			workbook.write(fos);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void CreateExcel_07_13(String filePath, String sheetName) {
		XSSFWorkbook workbook = new XSSFWorkbook();

		XSSFSheet sheet = workbook.createSheet("Sheet1");

		XSSFRow row = sheet.createRow(1);

		XSSFCell column = row.createCell(1);

		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePath));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			workbook.write(fos);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void toExcel(String filepath, String SheetName, int rowIndex, int columnIndex,
			Map<String, Object[]> map) throws FileNotFoundException {

		File file = new File(filepath);

		if (file.exists() == true) {
			System.out.println("File already exist");
		} else if (filepath.endsWith(".xlsx")) {
			StoreData.CreateExcel_07_13(filepath, SheetName);
		} else if (filepath.endsWith(".xls")) {
			StoreData.CreateExcel_97_03(filepath, SheetName);
		}

		FileInputStream fis = new FileInputStream(file);
		Workbook wb = null;
		try {
			wb = WorkbookFactory.create(fis);
		} catch (EncryptedDocumentException e) {

			e.printStackTrace();
		} catch (InvalidFormatException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

		Sheet sheet = wb.getSheet(SheetName);

		Set<String> Keyid = map.keySet();
		System.out.println(Keyid);
		System.out.println("Keyid" + Keyid);
		Iterator storeValue = Keyid.iterator();

		while (storeValue.hasNext()) {

			Row row = sheet.createRow(rowIndex++);

			String Key = (String) storeValue.next();
			System.out.println(Key);
			Object[] objArray = map.get(Key);// Here all values stored in Object
												// array
			columnIndex = 0;
			for (Object o1 : objArray) {

				System.out.println(o1);
				Cell cell = row.createCell(columnIndex++);
				System.out.println("cell" + cell);
				cell.setCellValue((String) o1);
			}
		}

		FileOutputStream fos = new FileOutputStream(file);
		try {
			wb.write(fos);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
public static void main(String[] args) throws FileNotFoundException {
	
	Object[] o1=new Object[]{"qwqlkw","qwkqlkw"};
	StoreData data=new StoreData();
	Map<String, Object[]> map=new HashMap();
	map.put("velan", (Object[]) new Object[]{"asaksajs","kfjdkfjdf"});
	data.toExcel("C:\\Users\\Indumathi\\Desktop\\Velan.xls", "Sheet1", 0, 0, map);
}
}
