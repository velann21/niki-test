package apk.bookmyShow.helper;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import apk.bookmyShow.Config.TestConfig;
//import WhatsApp1.Config.TestConfig;
import io.appium.java_client.AppiumDriver;

public class IlistnersIntializer extends TestConfig implements ITestListener {

	private static String fileSeperator = System.getProperty("file.separator");
	private Object newInstance;
	private Object object;
	AppiumDriver driv;

	public IlistnersIntializer() throws ClassNotFoundException, Exception, IllegalAccessException {

	}

	public void onFinish(ITestContext result) {

	}

	public void onStart(ITestContext result) {

	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	public void onTestFailure(ITestResult result) {
		Class c1 = null;
		try {
			c1 = Class.forName("apk.bookmyShow.Config.TestConfig");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		try {
			Field f1 = c1.getDeclaredField("driver");
			try {
				driv = (AppiumDriver) f1.get(f1);
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}

		String classname = getclassName(result.getInstanceName());
		String methodName = getMthodName(result.getName());
		String screenShotName = methodName + ".jpg";
		String imgPath = ".." + fileSeperator + "ScreenShots" + fileSeperator + "PassedScreenshots" + fileSeperator
				+ classname + screenShot(driv, screenShotName, classname);

	}

	public void onTestSkipped(ITestResult result) {

	}

	public void onTestStart(ITestResult result) {

	}

	public void onTestSuccess(ITestResult result) {

		Class c1 = null;
		try {
			c1 = Class.forName("apk.bookmyShow.Config.TestConfig");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		try {
			Field f1 = c1.getDeclaredField("driver");
			try {
				driv = (AppiumDriver) f1.get(f1);
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}

		String classname = getclassName(result.getInstanceName());
		String methodName = getMthodName(result.getName());
		String screenShotName = methodName + ".jpg";
		String imgPath = ".." + fileSeperator + "ScreenShots" + fileSeperator + "PassedScreenshots" + fileSeperator
				+ classname + screenShot(driv, screenShotName, classname);

	}

	public String getclassName(String classname) {
		String[] classarray = classname.split("\\.");
		int i = classarray.length - 1;
		return classarray[i];
	}

	public String getMthodName(String methodNamee) {
		String[] method = methodNamee.split("\\.");
		int arrsize = method.length - 1;
		return method[arrsize];

	}

	public String screenShot(WebDriver driver, String screenShotName, String testName) {

		Date date = new Date();
		String newDate = date.toString().replace(":", "_");
		File f1 = new File("ScreenShots" + fileSeperator + "PassedScreenshots" + fileSeperator + testName + newDate);
		if (!f1.exists()) {
			f1.mkdir();
		}
		EventFiringWebDriver driver1 = new EventFiringWebDriver(driver);
		File srcImg = driver1.getScreenshotAs(OutputType.FILE);
		File destImg = new File("screenshots" + fileSeperator + "PassedScreenshots" + fileSeperator + testName + newDate
				+ fileSeperator + screenShotName);
		try {
			FileUtils.copyFile(srcImg, destImg);
			return screenShotName;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
