package apk.bookmyShow.helper;

public interface DesiredCapabiltiesKeys {
	
static String appiumKey="AUTOMATIONNAME";
static String deviceNamekey="DEVICE_NAME";
static String javaScriptEnablerKey="SUPPORTS_JAVASCRIPT";
static String DontCloseAppKey="DONT_STOP_APP_ON_RESET";
static String appPathKey="app";
static String appActivityKey="APP_ACTIVITY";
static String appPkgKey="APP_PACKAGE";
static String applaunchExistingstatusKey="noReset";
static String appdestroylastKey="fullReset";
static String browserKey="BROWSER_NAME";
}
