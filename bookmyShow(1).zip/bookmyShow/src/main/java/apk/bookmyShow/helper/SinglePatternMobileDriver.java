package apk.bookmyShow.helper;

import java.net.URL;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public class SinglePatternMobileDriver<T> extends FirefoxDriver {
	
	private SinglePatternMobileDriver()
	{
		
	}
	static AndroidDriver driver=null;
	static IOSDriver driver1=null;
	 
	public static <T> AppiumDriver getMobileDriverInstance(String mobType,URL url,Capabilities Capabilities)
	{
		
		if(driver==null&& mobType .startsWith("Andriod"))
		{
			Thread.currentThread().setName("AndriodThread");
			System.out.println(Thread.currentThread().getName());
			driver=new AndroidDriver(url,Capabilities);
			return driver;
		}
		else if(driver1==null&& mobType .startsWith("IOS"))
		{
			Thread.currentThread().setName("IOSThread");
			driver1=new IOSDriver(url,Capabilities);
			return driver1;
		}
		else
		{
			if(Thread.currentThread().getName()=="Andriod")
			{
			return driver;
			}
			else
			{
				return driver1;
			}
		}
	
		
	}
	

	
}
