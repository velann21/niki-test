package apk.bookmyShow.Config;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByClassName;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

//import WhatsApp1.helper.SinglePatternMobileDriver;
import apk.bookmyShow.helper.GetData;
import apk.bookmyShow.helper.Handler;
import apk.bookmyShow.helper.SinglePatternMobileDriver;
import apk.bookmyShow.pomAction.CityHomePageAction;
import apk.bookmyShow.pomAction.LoginPageAction;
import apk.bookmyShow.pomAction.MainPageAction;
import apk.bookmyShow.pomAction.PickRegionAction;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidKeyCode;

public class TestConfig {
	public static AppiumDriver driver = null;
	static public GetData getters = GetData.newInstance();
	static public Handler handle = new Handler();
	static public String configFile = System.getProperty("user.dir");
	static public String confFile = configFile + "\\resources\\external_data\\config.properties";
	public String excelPath = configFile + getters.fromProperties(confFile, "TestExcel", "apk.bookmyShow.Config.TestConfig");;
	protected MainPageAction mainPageActionInstance;
	protected LoginPageAction loginpageInstance2;
	protected PickRegionAction pick;
	protected CityHomePageAction hp;
	private int home;

	@BeforeSuite
	public void intialization() {
		
		 
	}

	@BeforeMethod
	public void preCondition() throws GetData, MalformedURLException {
		String mobType = getters.fromProperties(confFile, "MobileType", "apk.bookmyShow.Config.TestConfig");
		if (mobType.equals("Android")) {
			DesiredCapabilities cap = handle.DesiredCapabilitiesNative_AppwithReset(
					getters.fromProperties(confFile, "APK_FILE", "apk.bookmyShow.Config.TestConfig"), getters);
			driver = SinglePatternMobileDriver.getMobileDriverInstance("Andriod",
					new URL(getters.fromProperties(confFile, "ServerURL", "apk.bookmyShow.Config.TestConfig")), cap);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			mainPageActionInstance = MainPageAction.MainPageActionInstance(driver, handle);
			loginpageInstance2 = LoginPageAction.loginpageInstance(driver, handle);
			pick = PickRegionAction.PickRegionActionInstance(driver, handle);
			hp = CityHomePageAction.CityHomePageActionInstance(driver, handle);

		}
	}

}
