package apk.bookmyShow.PagesDriver;

import io.appium.java_client.AppiumDriver;

public class Driver {
	
	protected AppiumDriver driver=null; 

}
