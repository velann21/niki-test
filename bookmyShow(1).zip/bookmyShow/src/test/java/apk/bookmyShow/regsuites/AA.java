package apk.bookmyShow.regsuites;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;


public class AA {

	@Test
	public void mm1() throws InterruptedException {
		
		
		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
		caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		caps.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
		caps.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, false);
		caps.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, false);
		caps.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);

		caps.setJavascriptEnabled(true);
		System.setProperty("webdriver.ie.driver",
				"D:\\BookMyShow\\bookmyShow\\resources\\Servers\\Selenium_Server\\IEDriverServer.exe");
		WebDriver driver = new InternetExplorerDriver(caps);

		driver.get("http://demo.guru99.com/selenium/guru99home/");
		// navigates to the page consisting an iframe

		driver.manage().window().maximize();
		JavascriptExecutor  jse = (JavascriptExecutor) driver;
		jse.executeScript(
				          "var childframe=document.getElementById('a077aa5e');" 
		                + "var iframe =childframe.contentWindow.document;"
						+ "var innerelement=iframe12.getElementsByTagName('a');" 
		                + "innerelement[0].click();");
		
		/*JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript(
				  "var childitem=document.getElementById('crysalid');"
				+ "var innerelement = childitem.contentWindow.document;"
				+ "var elementfind = iframe.getElementsByTagName('input');"
				+ "elementfind[0].value='test986;");
				
*/		
		Thread.sleep(10000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1); // switching the frame by ID
		Thread.sleep(2000);
		//driver.switchTo().frame("a077aa5e");
		System.out.println("********We are switch to the iframe*******");
		driver.findElement(By.xpath("html/body/a/img")).click();
		// Clicks the iframe

		System.out.println("*********We are done***************");
	}

}
