package apk.bookmyShow.regsuites;

import org.testng.annotations.Test;

public class BB {
	
			int rollno;  
			String name;  
			  
			BB(int rollno,String name){  
			this.rollno=rollno;  
			this.name=name;  
			}  
			  
			public Object clone()throws CloneNotSupportedException{  
			return super.clone();  
			}  
			  
			//@Test
			public static void main(String[] args){  
			try{  
			BB s1=new BB(101,"amit");  
			System.out.println(s1);  
			BB s2=(BB)s1.clone();
			System.out.println(s2);
			  
			System.out.println(s1.rollno+" "+s1.name);  
			System.out.println(s2.rollno+" "+s2.name);  
			  
			}catch(CloneNotSupportedException c){}  
			  System.out.println("Am in Catch block");
			}  
			  
	

}
