package apk.bookmyShow.regsuites;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Arraylist {

	static ArrayList s1;
	public static void main(String[] args) {

		
		ArrayList al=new ArrayList();
		al.add("AAAA");
		al.add("BBBB");
		al.add("CCCC");
		HashMap<String,ArrayList> hp=new HashMap<String,ArrayList>();
		hp.put("username", al);
		System.out.println(hp.get("username"));
		Set<Entry<String, ArrayList>> entrySet = hp.entrySet();
		Iterator<Entry<String, ArrayList>> iterator = entrySet.iterator();
		int i=0;
		while(iterator.hasNext())
		{
			Map.Entry me=(Map.Entry)iterator.next();
			
			 s1=(ArrayList)me.getValue();
			
			System.out.println(s1);
			//i++;
		}
		
			
	}

	public void mm1()
	{
	  	
	}

}
