package apk.bookmyShow.regsuites;

import org.testng.annotations.Test;

import apk.bookmyShow.Config.TestConfig;
import apk.bookmyShow.pomAction.CityHomePageAction;
import apk.bookmyShow.pomAction.LoginPageAction;
import apk.bookmyShow.pomAction.MainPageAction;
import apk.bookmyShow.pomAction.PickRegionAction;

//import apk.bookmyShow.Config.TestConfig;
//@Listeners(apk.bookmyShow.helper.IlistnersIntializer.class)
public class Test_Sc_01 extends TestConfig{

	
	
	
		@Test()
		public void tc_01()

		{

			MainPageAction mainPageActionInstance = MainPageAction.MainPageActionInstance(driver, handle);
			try {
				mainPageActionInstance.clickLoginButton();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			LoginPageAction loginpageInstance2 = LoginPageAction.loginpageInstance(driver, handle);
			loginpageInstance2.login("velann21@gmail.com", "Siar@123");
			PickRegionAction pick = PickRegionAction.PickRegionActionInstance(driver, handle);
			pick.searchCity_Scroll("Allahabad");
			CityHomePageAction hp= CityHomePageAction.CityHomePageActionInstance(driver, handle); 
			hp.pageRoller();
			
		}
		
		

	

}
