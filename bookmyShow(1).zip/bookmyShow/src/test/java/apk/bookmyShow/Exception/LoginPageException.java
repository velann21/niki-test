package apk.bookmyShow.Exception;

//import com.Whatsapp.pomAction.LoginPageAction;

public class LoginPageException extends RuntimeException{
	
	
	public LoginPageException()
	{
		
	}
	public LoginPageException(String Exception)
	{
		super(Exception);
	}

		
}
