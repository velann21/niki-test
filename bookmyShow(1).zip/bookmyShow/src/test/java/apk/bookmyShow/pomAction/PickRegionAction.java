package apk.bookmyShow.pomAction;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import apk.bookmyShow.helper.Handler;
import apk.bookmyShow.pombean.PickRegionBean;

//import com.Whatsapp.pombean.PickRegionBean;

//import WhatsApp1.helper.Handler;
import io.appium.java_client.AppiumDriver;

public class PickRegionAction {
	PickRegionBean pickRegionBean;
	Handler handle;
	String regoin;
	AppiumDriver driver;

	private PickRegionAction(AppiumDriver driver, Handler handle) {
		pickRegionBean = PickRegionBean.PickRegionBeanInstance(driver);
		this.handle = handle;
		this.driver = driver;

	}

	public static PickRegionAction PickRegionActionInstance(AppiumDriver driver, Handler handle) {
		return new PickRegionAction(driver, handle);
	}

	public void searchCity(String cityName) {
		handle.click_Button(pickRegionBean.getSearchLogo());
		handle.text_Writer(pickRegionBean.getSearchTextBox(), cityName);
		//System.out.println("Going to enter the List");
        List<WebElement> listCities = pickRegionBean.getTopCities();
		System.out.println("Am in List" + listCities);
		for (int i = 0; i < listCities.size(); i++) {
			String regoin = listCities.get(i).getText();
			System.out.println("region is" + regoin);
			if (regoin.equals(cityName)) {
				listCities.get(i).click();
				break;
			}

		}

	}

	public void searchCity_Scroll(String cityName) {
		List<WebElement> listCities = pickRegionBean.getTopCities();

		do {
			for (int i = 0; i < listCities.size(); i++) {
				regoin = listCities.get(i).getText();
				System.out.println("region is" + regoin);
				if (regoin.equals(cityName)) {
					listCities.get(i).click();
					break;
				}
			}

			if(regoin.equals(cityName))
			{
				
				if (pickRegionBean.getChecker().isDisplayed() == true) {
					break;
				}
			}
				WebElement listView = pickRegionBean.getPageListView();
				int xAxis = listView.getLocation().getX();
				System.out.println("xaxis: " + xAxis);
				int yAxis = listView.getLocation().getY();
				System.out.println("YAxis :" + yAxis);
				int heightPage = listView.getSize().height;
				System.out.println("HeightPage :" + heightPage);
				handle.page_Scroller(driver, xAxis, heightPage, xAxis, yAxis, 1000);
				listCities = driver.findElements(By.id("com.bt.bms:id/ctxv_region_name"));
			
		} while (regoin.equals("Allahabad") == false);

		// handle.click_Button(driver.findElement(By.id("com.bt.bms:id/tvcta")));
	}
}
