package apk.bookmyShow.pomAction;

//import com.Whatsapp.pombean.CityHomePageBean;

import apk.bookmyShow.helper.Handler;
import apk.bookmyShow.pombean.CityHomePageBean;
//import WhatsApp1.helper.Handler;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;

public class CityHomePageAction {
	AppiumDriver driver;
	CityHomePageBean homepage;
	Handler handle;
	private CityHomePageAction(AppiumDriver driver,Handler handle)
	{
		this.driver=driver;
		this.handle=handle;
		homepage=CityHomePageBean.CityHomePageBeanInstance(driver);
	}
	
	public static CityHomePageAction CityHomePageActionInstance(AppiumDriver driver,Handler handle2)
	{
		return new CityHomePageAction(driver,handle2);
	}
	
	public void showCaseSelector()
	{
		handle.click_Button(homepage.getShowCaseTab());
	}
	
	public void ticketstabSelector()
	{
		handle.click_Button(homepage.getTicketsTab());
	}
	
	public void youTabSelector()
	{
		handle.click_Button(homepage.getYouTab());
	}
	
	public void discoverTabSelector()
	{
		handle.click_Button(homepage.getDiscoverTab());
	}
	
	public void pageRoller()
	{
		TouchAction action=new TouchAction(driver);
		//action.press(853, 1147).moveTo(853,674).release().perform();
		System.out.println("Am going to emter the touch");
		//driver.swipe(853, 524, 853, 1530, 1000);
		action.longPress(853, 524).moveTo(853,1530).release().perform();
		handle.click_Button(homepage.getSkipPage());
		System.out.println("Completed");
	}

}
