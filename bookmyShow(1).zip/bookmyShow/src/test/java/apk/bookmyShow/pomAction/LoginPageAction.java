package apk.bookmyShow.pomAction;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;

import apk.bookmyShow.Exception.LoginPageException;
import apk.bookmyShow.helper.Handler;
import apk.bookmyShow.pombean.LoginBean;
import apk.bookmyShow.pombean.PickRegionBean;
import io.appium.java_client.AppiumDriver;

public class LoginPageAction {
    By waiter=By.id("com.bt.bms:id/action_icon");
	LoginBean loginBean;
	Handler handle;
	AppiumDriver driver;
	private PickRegionBean pickRegionBeanInstance;

	private LoginPageAction(AppiumDriver driver, Handler handle) {
		loginBean = LoginBean.getLoginPageInstance(driver);
		this.driver = driver;
		this.handle = handle;
	}

	public static LoginPageAction loginpageInstance(AppiumDriver driver, Handler handle) {
		return new LoginPageAction(driver, handle);
	}

	public void login(String username, String password) {
		if (username == null) {
			throw new LoginPageException("username name null exception");
		}
		// System.out.println(loginBean.getEmailAddressTextBox().getText());
		// handle.text_WriterArrays(new
		// WebElement[]{loginBean.getEmailAddressTextBox(),loginBean.getPasswordTextBox()},
		// new String[]{username,password});
		handle.text_Writer(loginBean.getEmailAddressTextBox(), username);
		handle.text_Writer(loginBean.getPasswordTextBox(), password);
		handle.click_Button(loginBean.getSignButton());
		
		pickRegionBeanInstance = PickRegionBean.PickRegionBeanInstance(driver);
		try
		{
		condtionWait();
		if (pickRegionBeanInstance.getSearchLogo().isDisplayed() == true) {
			System.out.println("Internet is 'ON'");
		}
		} catch(Exception e) {
			handle.click_Button(loginBean.getPopUpElement());
			JOptionPane.showMessageDialog(null, "Kindly 'ON' the Internet in your mobile ", "Mobile " +"Internet", 
	                JOptionPane.INFORMATION_MESSAGE);
			
		}
	}
	
	public void condtionWait(){
		handle.elementToPresentWaiter(driver,waiter);
	}

}
