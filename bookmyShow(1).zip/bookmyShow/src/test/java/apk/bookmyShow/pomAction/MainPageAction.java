package apk.bookmyShow.pomAction;

//import com.Whatsapp.pombean.MainBean;

import apk.bookmyShow.helper.Handler;
import apk.bookmyShow.pombean.MainBean;
//import WhatsApp1.helper.Handler;
import io.appium.java_client.AppiumDriver;

public class MainPageAction {
	MainBean mainBean;
	Handler handle1;
	private MainPageAction(AppiumDriver driver,Handler handle)
	{
		mainBean=MainBean.getMainPageInstace(driver);
		this.handle1=handle;
	}
	
	public static MainPageAction MainPageActionInstance(AppiumDriver driver,Handler handle)
	{
		return new MainPageAction(driver,handle);
		
	}
	
	public void clickLoginButton() throws InterruptedException
	{
		//Thread.sleep(3000);
		handle1.click_Button(mainBean.getLoginButton());
	}
	
	public void clickSkipButton()
	{
		handle1.click_Button(mainBean.getSkipButton());
		
	}
}
