package apk.bookmyShow.pombean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import apk.bookmyShow.PagesDriver.Driver;

//import com.Whatsapp.PagesDriver.Driver;

import io.appium.java_client.AppiumDriver;

public class PickRegionBean extends Driver{
	
	//AppiumDriver driver;
	private PickRegionBean(AppiumDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public static PickRegionBean PickRegionBeanInstance(AppiumDriver driver)
	{
		return new PickRegionBean(driver);
	}
	@CacheLookup
	@FindBy(id="com.bt.bms:id/action_icon")
	public WebElement searchLogo;

	@CacheLookup
	@FindBy(id="com.bt.bms:id/edtSearchBox")
	private WebElement searchTextBox;

	@CacheLookup
	@FindBy(id="com.bt.bms:id/ctxv_region_name")
	private List<WebElement> topCities;
	
	@CacheLookup
	@FindBy(id="com.bt.bms:id/listView")
	private WebElement pageListView;
	
	@CacheLookup
	@FindBy(id="com.bt.bms:id/tvcta")
	private WebElement checker;
	
	public WebElement getChecker() {
		return checker;
	}
	public void setChecker(WebElement checker) {
		this.checker = checker;
	}
	public AppiumDriver getDriver() {
		return driver;
	}
	public void setDriver(AppiumDriver driver) {
		this.driver = driver;
	}
	public WebElement getSearchLogo() {
		return searchLogo;
	}
	public void setSearchLogo(WebElement searchLogo) {
		this.searchLogo = searchLogo;
	}
	public WebElement getSearchTextBox() {
		return searchTextBox;
	}
	public void setSearchTextBox(WebElement searchTextBox) {
		this.searchTextBox = searchTextBox;
	}
	public List<WebElement> getTopCities() {
		return topCities;
	}
	public void setTopCities(List<WebElement> topCities) {
		this.topCities = topCities;
	}
    
	public WebElement getPageListView() {
		return pageListView;
	}
	public void setPageListView(WebElement pageListView) {
		this.pageListView = pageListView;
	}
}
