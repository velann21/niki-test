package apk.bookmyShow.pombean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import apk.bookmyShow.PagesDriver.Driver;

//import com.Whatsapp.PagesDriver.Driver;

import io.appium.java_client.AppiumDriver;

public class LoginBean extends Driver{
	
	//AppiumDriver driver;
	private LoginBean(AppiumDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	public static LoginBean getLoginPageInstance(AppiumDriver driver)
	{
		return new LoginBean(driver);
		
	}

	@FindBy(id ="com.bt.bms:id/edtemail")
	private WebElement emailAddressTextBox;

	@FindBy(id ="com.bt.bms:id/edtpass")
	private WebElement passwordTextBox;

	@FindBy(id ="com.bt.bms:id/signin")
	private WebElement signButton;
	
	@FindBy(id="com.bt.bms:id/dismiss")
	private WebElement popUpElement;

	
	
	public WebElement getPopUpElement() {
		return popUpElement;
	}

	public void setPopUpElement(WebElement popUpElement) {
		this.popUpElement = popUpElement;
	}

	public WebElement getEmailAddressTextBox() {
		return emailAddressTextBox;
	}

	public void setEmailAddressTextBox(WebElement emailAddressTextBox) {
		this.emailAddressTextBox = emailAddressTextBox;
	}

	public WebElement getPasswordTextBox() {
		return passwordTextBox;
	}

	public void setPasswordTextBox(WebElement passwordTextBox) {
		this.passwordTextBox = passwordTextBox;
	}

	public WebElement getSignButton() {
		return signButton;
	}

	public void setSignButton(WebElement signButton) {
		this.signButton = signButton;
	}

}



