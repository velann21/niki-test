package apk.bookmyShow.pombean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import apk.bookmyShow.PagesDriver.Driver;

//import com.Whatsapp.PagesDriver.Driver;


import io.appium.java_client.AppiumDriver;

public class MainBean extends Driver{
	//AppiumDriver driver;

	private MainBean(AppiumDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public static MainBean getMainPageInstace(AppiumDriver driver)
	{
		return new MainBean(driver);
		
	}
	
	@FindBy(id ="com.bt.bms:id/btnLogin")
	private WebElement loginButton;

	@FindBy(id = "com.bt.bms:id/btnNoThanks")
	private WebElement skipButton;

	public WebElement getSkipButton() {
		return skipButton;
	}

	public void setSkipButton(WebElement skipButton) {
		this.skipButton = skipButton;
	}

	public WebElement getLoginButton() {
		return loginButton;
	}

	public void setLoginButton(WebElement loginButton) {
		this.loginButton = loginButton;
	}

	public void loginButton_Click()
	{
		getLoginButton().click();
	}
	public void skipButton_Click()
	{
		getSkipButton().click();
	}


}
