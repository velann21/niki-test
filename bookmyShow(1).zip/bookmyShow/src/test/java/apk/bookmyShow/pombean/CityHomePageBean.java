package apk.bookmyShow.pombean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import apk.bookmyShow.PagesDriver.Driver;

//import com.Whatsapp.PagesDriver.Driver;

import io.appium.java_client.AppiumDriver;

public class CityHomePageBean extends Driver {

	// AppiumDriver driver;
	private CityHomePageBean(AppiumDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public static CityHomePageBean CityHomePageBeanInstance(AppiumDriver driver)
	{
		return new CityHomePageBean(driver);
	}
	
	@FindBy(xpath="//android.widget.TextView[contains(@text='SHOWCASE')]")
	private WebElement showCaseTab;
	
	@FindBy(xpath="//android.widget.TextView[contains(@text='TICKETS')]")
	private WebElement ticketsTab;
	
	@FindBy(xpath="//android.widget.TextView[contains(@text='YOU')]")
	private WebElement youTab;
	
	@FindBy(xpath="//android.widget.TextView[contains(@text='DISCOVER')]")
	private WebElement discoverTab;
	
	@FindBy(id="com.bt.bms:id/movie_cta")
	private WebElement moviePages;

	@FindBy(xpath="//android.widget.TextView[contains(@text='Book Now')]")
	private WebElement moviePagesBookNow;

	@FindBy(id="com.bt.bms:id/dArrow1")
	private List<WebElement> upArrow;
	
	@FindBy(xpath="//android.widget.TextView[@text='Skip']")
	private WebElement skipPage;

	public WebElement getSkipPage() {
		return skipPage;
	}

	public void setSkipPage(WebElement skipPage) {
		this.skipPage = skipPage;
	}

	public WebElement getShowCaseTab() {
		return showCaseTab;
	}

	public void setShowCaseTab(WebElement showCaseTab) {
		this.showCaseTab = showCaseTab;
	}

	public WebElement getTicketsTab() {
		return ticketsTab;
	}

	public void setTicketsTab(WebElement ticketsTab) {
		this.ticketsTab = ticketsTab;
	}

	public WebElement getYouTab() {
		return youTab;
	}

	public void setYouTab(WebElement youTab) {
		this.youTab = youTab;
	}

	public WebElement getDiscoverTab() {
		return discoverTab;
	}

	public void setDiscoverTab(WebElement discoverTab) {
		this.discoverTab = discoverTab;
	}

	public WebElement getMoviePages() {
		return moviePages;
	}

	public void setMoviePages(WebElement moviePages) {
		this.moviePages = moviePages;
	}

	public WebElement getMoviePagesBookNow() {
		return moviePagesBookNow;
	}

	public void setMoviePagesBookNow(WebElement moviePagesBookNow) {
		this.moviePagesBookNow = moviePagesBookNow;
	}

	public List<WebElement> getUpArrow() {
		return upArrow;
	}

	public void setUpArrow(List<WebElement> upArrow) {
		this.upArrow = upArrow;
	}


}
