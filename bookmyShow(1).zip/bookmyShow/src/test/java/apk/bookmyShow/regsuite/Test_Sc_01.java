package apk.bookmyShow.regsuite;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import apk.bookmyShow.Config.TestConfig;
import apk.bookmyShow.pomAction.CityHomePageAction;
import apk.bookmyShow.pomAction.LoginPageAction;
import apk.bookmyShow.pomAction.MainPageAction;
import apk.bookmyShow.pomAction.PickRegionAction;
@Listeners(apk.bookmyShow.helper.IlistnersIntializer.class)
public class Test_Sc_01 extends TestConfig {
	@Test()
	public void tc_01()
	{
		ArrayList userNameList = null;
		ArrayList passwordList = null;
		ArrayList region = null;
		try {
			userNameList = getters.fromExcelValueExtractor(excelPath, "ConfigSheet", "Test_Sc_01", "InputSheet",
					getters, 1);
			passwordList = getters.fromExcelValueExtractor(excelPath, "ConfigSheet", "Test_Sc_01", "InputSheet",
					getters, 2);
			region = getters.fromExcelValueExtractor(excelPath, "ConfigSheet", "Test_Sc_01", "InputSheet", getters, 3);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
		for (int i = 0; i <= userNameList.size(); i++) {
			try {
				mainPageActionInstance.clickLoginButton();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			loginpageInstance2.login((String) userNameList.get(i), (String) passwordList.get(i));
			//loginpageInstance2.condtionWait();
			pick.searchCity_Scroll((String) region.get(i));
			hp.pageRoller();
			driver.resetApp();
		}
	}
}
