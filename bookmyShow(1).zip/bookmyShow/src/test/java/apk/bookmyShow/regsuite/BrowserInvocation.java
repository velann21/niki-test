package apk.bookmyShow.regsuite;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class BrowserInvocation {

	@Test
	public static void browserInvocation() throws MalformedURLException {

		DesiredCapabilities capabilities = DesiredCapabilities.android();
		// set the capability to execute test in chrome browser
		capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, BrowserType.CHROME);
		// set the capability to execute our test in Android Platform
		capabilities.setCapability(MobileCapabilityType.PLATFORM, Platform.ANDROID);
		// we need to define platform name
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		// Set the device name as well (you can give any name)
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "SSVOSGSGAE75856P");
		// set the android version as well
		capabilities.setCapability(MobileCapabilityType.VERSION, "6.1");
		// Create object of URL class and specify the appium server address
		URL url = new URL("http://127.0.0.1:4720/wd/hub");
		// Create object of AndroidDriver class and pass the url and capability
		// that we created
		WebDriver driver = new AndroidDriver(url, capabilities);
		// Open url
		driver.get("http://www.google.com");
		// print the title
		System.out.println("Title " + driver.getTitle());
		// enter SearchBox Value
		driver.findElement(By.id("lst-ib")).sendKeys("Velan");
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		List<WebElement> list = driver.findElements(By.xpath("//ul[@class='sbsb_b']//li"));
		System.out.println(list.size());
		for (WebElement w1 : list) {
			String value = w1.getText();
			System.out.println(value);

			if (value.equals("velankani")) {
				System.out.println("Am goign to click");
				w1.click();
				System.out.println("Am clicked");
				break;
				// driver=new AndroidDriver(url, capabilities);
			}
			driver.findElement(By.linkText("Images")).click();

		}
	}
}
